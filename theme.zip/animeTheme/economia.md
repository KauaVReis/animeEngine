Relatório de Planeamento: Protocolo de Créditos Matrix (v3.6)

Este documento detalha o sistema de economia simulada proposto para a próxima grande atualização do AnimeEngine. O objetivo é aumentar o tempo de retenção do utilizador e criar camadas de interação social hacker.

1. O Recurso: Neural Credits (₡)

Os créditos serão a "moeda" da rede. Não têm valor real, mas garantem prestígio e controlo sobre a rádio.

Mecanismos de Ganho (Mining)

Time-on-Site: Cada 1 minuto com a rádio ligada gera ₡1.

Protocolo de Consenso: Votar em um Skip que seja bem-sucedido gera ₡2.

Interação Neural: Falar no chat ou enviar reações gera ₡2 (limite de uma vez por música).

Early Node: Ser um dos primeiros 5 utilizadores a entrar na rádio após um reset do sistema gera ₡10.

2. Evolução de Identidade: O Botão Google

Para garantir que a economia seja justa e que os utilizadores não percam o seu progresso, o sistema passará a suportar dois níveis de acesso:

2.1 Agente Convidado (Guest - Anónimo)

Acesso: Instantâneo via signInAnonymously.

Persistência: Limitada ao dispositivo/cache do browser.

Limitação: Se limpar os dados ou mudar de PC, o saldo de ₡ é perdido.

Mensagem de Conversão: "Estás a operar como Convidado. Faz login com o Google para encriptar os teus créditos na nuvem."

2.2 Agente Certificado (Google Auth)

Acesso: Autenticação via Google Firebase Provider.

Persistência: Total. Saldo sincronizado em qualquer dispositivo.

Vantagem de Rede: Apenas Agentes Certificados podem aparecer no Global Leaderboard.

3. O Mercado: Utilização de Créditos

Função

Custo

Nível Requerido

Descrição

Tip (Donativo)

Variável

Qualquer

Enviar ₡X para outro Agente no chat.

Override Command

₡500

Certificado

Forçar a troca imediata da música sem votação.

Oracle Request

₡50

Qualquer

Fazer uma pergunta direta ao Oráculo.

Identity Hue

₡100

Qualquer

Mudar a cor do nome no chat por 1 hora.

Global Broadcast

₡200

Certificado

Exibir mensagem no Marquee para todos por 30s.

FX Hijack

₡300

Certificado

Mudar a cor da Matrix de todos por 2 minutos.

Consensus Weight

₡150

Qualquer

O seu próximo voto de Skip contará por 2.

4. Arquitetura Técnica (Firestore & Auth)

Estrutura de Dados

/artifacts/{appId}/users/{userId}/wallet: Documento guardando o saldo. O userId será o UID do Google ou o UID anónimo.

/artifacts/{appId}/public/data/leaderboard: Lista dos top 5 agentes (filtrada para apenas mostrar UIDs vinculados ao Google).

Segurança (Rules)

Impedir que utilizadores anónimos executem funções de "Global Broadcast" ou "Override" para evitar abusos (bots ou scripts de refresh).

Validar no Firestore se o utilizador tem saldo suficiente antes de processar qualquer transação.

5. Próximos Passos

Interface: Adicionar o botão "Login com Google" na aba SYS.

Migração: Criar uma lógica que transfere o saldo do utilizador anónimo para a conta Google assim que ele faz o primeiro login.

Feedback Visual: Criar a animação de "₡" subindo no canto do ecrã ao ganhar créditos.

Status da Proposta: Aguardando Aprovação para v3.6.